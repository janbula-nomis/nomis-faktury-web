/**
 * netlify/functions/smlouvy.js
 * Správa Smluv (trvalé příkazy - nájem, elektřina, leasing apod., od v3.19,
 * viz claude/nomis-faktury-backlog.md) - list "Smlouvy" v Sheets.
 *
 * Přístup jen pro role "admin" a "ucetni" - stejné omezení jako u
 * Bankovních výpisů (netlify/functions/banka.js), protože Smlouvy jsou
 * s bankovními pohyby úzce propojené (viz Bankovni_pohyby.Smlouva_ID).
 *
 * GET    ?firma=Nazev  -> { smlouvy: [...], prilohy: [...] } smluv dané
 *                         firmy + jejich přílohy (Smlouvy_Prilohy, od
 *                         v3.21 - viz lib/smlouvyPrilohySchema.js).
 * GET    (bez firma)   -> totéž pro všechny smlouvy viditelné uživateli
 *                         (admin vše, účetní jen firmy, které má přiřazené) -
 *                         používá se v hlavní záložce Smlouvy.
 * POST   { Firma, Nazev, Druha_strana?, Stredisko?, Typ?, Perioda?,
 *          Ocekavana_castka?, Mena?, Platnost_od?, Platnost_do?,
 *          Zdrojovy_soubor_URL?, Poznamka?, Aktivni? }
 *          -> založí novou
 *          smlouvu ručně, bez souboru/AI
 *          (Aktivni výchozí "ANO"). Založení PŘES nahraný soubor + AI
 *          vytěžení appka řeší samostatně, viz smlouvy-upload.js a
 *          smlouvy-upload-dokoncit.js.
 * PATCH  { id, zmeny } -> úprava libovolných polí smlouvy
 * DELETE ?id=X -> smazání smlouvy; appka zároveň "odpojí" bankovní pohyby
 *          napojené na smazanou smlouvu (Bankovni_pohyby.Smlouva_ID == id),
 *          vrátí je do stavu "Nespárováno" (stejný vzor jako u smazání
 *          Dokladu, viz netlify/functions/doklady.js), a smaže i všechny
 *          přílohy smlouvy ze Smlouvy_Prilohy (appka soubory samotné na
 *          Drive neodstraňuje, stejná konvence jako u smazání Dokladu).
 */
const { requireAuth } = require('../../lib/requireAuth');
const { getSheetsClient } = require('../../lib/google');
const { readSheetObjects, appendRow, updateRow, deleteRow } = require('../../lib/sheetsHelpers');
const { SMLOUVY_HEADERS, dalsiPoradiSmlouvy } = require('../../lib/smlouvySchema');
const { BANKOVNI_HEADERS } = require('../../lib/bankSchema');
const { vygenerujCisloSmlouvy } = require('../../lib/cisloSmlouvy');
const { idZeSdileneUrl } = require('../../lib/driveHelpers');
const { json } = require('../../lib/http');
const crypto = require('crypto');

function maPristupKFirme(uzivatel, firma) {
  return uzivatel.role === 'admin' || (uzivatel.firmy || []).includes(firma);
}

// v4.36 - u nájemní smlouvy appka rozděluje čistý nájem a zálohu na
// služby (viz komentář u SMLOUVY_HEADERS v lib/smlouvySchema.js), ale
// `Ocekavana_castka` dál appka počítá/ukládá jako jejich součet, ať
// stávající spárování bankovních plateb podle přesné částky
// (lib/bankHelpers.js) zůstane beze změny - appka jen navíc ví, jak se
// ta částka skládá. Od v4.37 appka STEJNOU funkci používá i u nákladové
// smlouvy (Typ != 'Nájem', typicky SVJ/pojistka) pro součet
// Sluzby_castka + Vlastni_naklad_castka - jde o stejný princip (appka
// zná rozpad, ale párování bankovní platby pořád jede podle jednoho
// součtu), proto appka funkci přejmenovala na obecnější název.
function soucetDvouCastek(a, b) {
  return String((parseFloat(a) || 0) + (parseFloat(b) || 0));
}

exports.handler = async (event) => {
  if (event.httpMethod === 'OPTIONS') return json(200, {});

  let uzivatel;
  try {
    uzivatel = requireAuth(event);
  } catch (e) {
    return json(e.statusCode || 401, { error: e.message });
  }
  if (uzivatel.role !== 'admin' && uzivatel.role !== 'ucetni') {
    return json(403, { error: 'Smlouvy jsou dostupné jen administrátorovi a účetní.' });
  }

  const sheets = await getSheetsClient();
  const spreadsheetId = process.env.SPREADSHEET_ID;

  try {
    if (event.httpMethod === 'GET') {
      // Oprava v4.22 - appka firmu z query parametru ořezává stejně jako
      // při zápisu (POST), jinak by název firmy se stray mezerou navíc
      // (typicky firma přejmenovaná přímo v Sheets) appce znemožnil najít
      // vlastní čerstvě zapsaná data - viz plné vysvětlení v banka.js.
      const firma = String((event.queryStringParameters || {}).firma || '').trim();
      const { rows } = await readSheetObjects(sheets, spreadsheetId, 'Smlouvy');

      // Placeholder smlouva "Zpracovává se" ještě nemá potvrzenou Firmu -
      // appka ji přesto appka ukáže tomu, kdo ji nahrál (nebo adminovi),
      // stejná logika jako u placeholder Dokladů (viz doklady.js).
      const viditelnostSmlouvy = (r) =>
        (r.Firma && maPristupKFirme(uzivatel, r.Firma)) ||
        (!r.Firma && (uzivatel.role === 'admin' || r.Nahral_uzivatel === uzivatel.jmeno));

      let viditelne;
      if (firma) {
        if (!maPristupKFirme(uzivatel, firma)) return json(403, { error: 'Nemáte přístup k této firmě.' });
        viditelne = rows.filter((r) => r.Firma === firma || (!r.Firma && viditelnostSmlouvy(r)));
      } else {
        viditelne = rows.filter(viditelnostSmlouvy);
      }

      // Přílohy appka vrací rovnou spolu se smlouvami (ne jako samostatný
      // dotaz na smlouvu) - frontend si je seskupí podle Smlouva_ID lokálně,
      // stejný vzor jako u ostatních 1:N vztahů v appce (např. propojený
      // doklad u bankovního pohybu). List Smlouvy_Prilohy nemusí ještě
      // existovat na starší appce bez znovu spuštěného /api/setup.
      let prilohy = [];
      try {
        const viditelnaId = new Set(viditelne.map((r) => r.ID));
        const { rows: prilohyVsechny } = await readSheetObjects(sheets, spreadsheetId, 'Smlouvy_Prilohy');
        prilohy = prilohyVsechny.filter((p) => viditelnaId.has(p.Smlouva_ID));
      } catch (e) {
        // List Smlouvy_Prilohy zatím neexistuje - appka jen vrátí prázdné
        // pole, ať appka nespadne, dokud se znovu nespustí /api/setup.
      }

      // (v4.43) U starších smluv a příloh, kde je vyplněný jen ručně vložený
      // odkaz na Drive a ne ID souboru, si appka ID z odkazu vytáhne rovnou
      // v odpovědi. Do tabulky se nic nezapisuje (žádná migrace) - jde jen o
      // to, aby frontend měl čím zavolat /api/soubor a nemusel uživatele
      // posílat na drive.google.com, kde by kolega narazil na "Potřebujete
      // přístup". Viz idZeSdileneUrl() v lib/driveHelpers.js.
      const doplnIdZOdkazu = (r) => {
        if (!r.Zdrojovy_soubor_ID && r.Zdrojovy_soubor_URL) {
          r.Zdrojovy_soubor_ID = idZeSdileneUrl(r.Zdrojovy_soubor_URL);
        }
        return r;
      };
      viditelne.forEach(doplnIdZOdkazu);
      prilohy.forEach(doplnIdZOdkazu);

      return json(200, { smlouvy: viditelne, prilohy });
    }

    if (event.httpMethod === 'POST') {
      const telo = JSON.parse(event.body || '{}');
      const firma = String(telo.Firma || '').trim();
      const nazev = String(telo.Nazev || '').trim();
      if (!firma) return json(400, { error: 'Vyberte firmu.' });
      if (!maPristupKFirme(uzivatel, firma)) return json(403, { error: 'Nemáte přístup k této firmě.' });
      if (!nazev) return json(400, { error: 'Název smlouvy je povinný.' });

      // Číslo smlouvy appka přiděluje hned při ručním založení (od v4.2) -
      // u nahrané/AI-vytěžené smlouvy se přiděluje až po úspěšném zpracování,
      // viz smlouvy-upload-dokoncit.js.
      const { rows: existujiciSmlouvy } = await readSheetObjects(sheets, spreadsheetId, 'Smlouvy');
      const cisloSmlouvy = vygenerujCisloSmlouvy(existujiciSmlouvy, new Date().getFullYear());
      // Pořadí appka přiděluje stejně, ať appka smlouvu vždy přidá na konec
      // vlastního pořadí uživatele (v4.14), ne doprostřed.
      const poradi = dalsiPoradiSmlouvy(existujiciSmlouvy);

      const typSmlouvy = String(telo.Typ || '').trim();
      const cistyNajem = String(telo.Cisty_najem || '').trim();
      const zalohaNaSluzby = String(telo.Zaloha_na_sluzby || '').trim();
      const sluzbyCastka = String(telo.Sluzby_castka || '').trim();
      const vlastniNakladCastka = String(telo.Vlastni_naklad_castka || '').trim();
      // U nájmu appka počítá Ocekavana_castka ze split polí čistý nájem/
      // záloha, pokud je appka dostala. U jiného typu smlouvy (od v4.37,
      // typicky SVJ/pojistka navázaná na nemovitost) appka stejně počítá
      // součet Sluzby_castka/Vlastni_naklad_castka, pokud appka dostala
      // aspoň jedno z nich - jinak appka bere Ocekavana_castka tak, jak
      // appka dostala (starší chování, běžný "trvalý příkaz" nesouvisející
      // s vyúčtováním nemovitosti split pole vůbec nepoužívá).
      let ocekavanaCastka;
      if (typSmlouvy === 'Nájem' && (cistyNajem || zalohaNaSluzby)) {
        ocekavanaCastka = soucetDvouCastek(cistyNajem, zalohaNaSluzby);
      } else if (typSmlouvy !== 'Nájem' && (sluzbyCastka || vlastniNakladCastka)) {
        ocekavanaCastka = soucetDvouCastek(sluzbyCastka, vlastniNakladCastka);
      } else {
        ocekavanaCastka = telo.Ocekavana_castka !== undefined ? String(telo.Ocekavana_castka).trim() : '';
      }

      const smlouva = {
        ID: crypto.randomUUID(),
        Cislo_smlouvy: cisloSmlouvy,
        Firma: firma,
        Nazev: nazev,
        Druha_strana: String(telo.Druha_strana || '').trim(),
        Stredisko: String(telo.Stredisko || '').trim(),
        Typ: typSmlouvy,
        Perioda: String(telo.Perioda || '').trim(),
        Ocekavana_castka: ocekavanaCastka,
        Mena: String(telo.Mena || 'CZK').trim() || 'CZK',
        Platnost_od: String(telo.Platnost_od || '').trim(),
        Platnost_do: String(telo.Platnost_do || '').trim(),
        Zdrojovy_soubor_URL: String(telo.Zdrojovy_soubor_URL || '').trim(),
        // (v4.43) Když uživatel vyplnil jen odkaz, ID si appka vytáhne z něj -
        // ať je sken od začátku otevíratelný přes appku, ne přes Google.
        Zdrojovy_soubor_ID:
          String(telo.Zdrojovy_soubor_ID || '').trim() ||
          idZeSdileneUrl(telo.Zdrojovy_soubor_URL),
        Poznamka: String(telo.Poznamka || '').trim(),
        Aktivni: String(telo.Aktivni || 'ANO').trim() || 'ANO',
        Poradi: String(poradi),
        Cisty_najem: cistyNajem,
        Zaloha_na_sluzby: zalohaNaSluzby,
        Kauce_castka: String(telo.Kauce_castka || '').trim(),
        Kauce_datum_prijeti: String(telo.Kauce_datum_prijeti || '').trim(),
        Kauce_stav: String(telo.Kauce_stav || '').trim(),
        Kauce_poznamka: String(telo.Kauce_poznamka || '').trim(),
        Sluzby_castka: sluzbyCastka,
        Vlastni_naklad_castka: vlastniNakladCastka,
      };
      await appendRow(sheets, spreadsheetId, 'Smlouvy', SMLOUVY_HEADERS, smlouva);

      return json(200, { ok: true, smlouva });
    }

    if (event.httpMethod === 'PATCH') {
      const { id, zmeny } = JSON.parse(event.body || '{}');
      if (!id) return json(400, { error: 'Chybí ID smlouvy.' });

      const { rows } = await readSheetObjects(sheets, spreadsheetId, 'Smlouvy');
      const smlouva = rows.find((r) => r.ID === id);
      if (!smlouva) return json(404, { error: 'Smlouva nenalezena.' });
      if (!maPristupKFirme(uzivatel, smlouva.Firma)) return json(403, { error: 'Nemáte přístup k této firmě.' });

      const aktualizovana = Object.assign({}, smlouva, zmeny || {});
      // v4.36/v4.37 - appka přepočítá Ocekavana_castka jen tehdy, když
      // PATCH skutečně mění jedno ze split polí u DANÉHO typu smlouvy -
      // jinak appka Ocekavana_castka nechává beze změny (např. PATCH, který
      // mění jen Poznamku, na částku nesahá).
      if (aktualizovana.Typ === 'Nájem'
        && ((zmeny || {}).Cisty_najem !== undefined || (zmeny || {}).Zaloha_na_sluzby !== undefined)) {
        aktualizovana.Ocekavana_castka = soucetDvouCastek(
          aktualizovana.Cisty_najem, aktualizovana.Zaloha_na_sluzby
        );
      } else if (aktualizovana.Typ !== 'Nájem'
        && ((zmeny || {}).Sluzby_castka !== undefined || (zmeny || {}).Vlastni_naklad_castka !== undefined)) {
        aktualizovana.Ocekavana_castka = soucetDvouCastek(
          aktualizovana.Sluzby_castka, aktualizovana.Vlastni_naklad_castka
        );
      }
      await updateRow(sheets, spreadsheetId, 'Smlouvy', SMLOUVY_HEADERS, smlouva._row, aktualizovana);

      return json(200, { ok: true });
    }

    if (event.httpMethod === 'DELETE') {
      const id = (event.queryStringParameters || {}).id;
      if (!id) return json(400, { error: 'Chybí ID smlouvy.' });

      const { rows } = await readSheetObjects(sheets, spreadsheetId, 'Smlouvy');
      const smlouva = rows.find((r) => r.ID === id);
      if (!smlouva) return json(404, { error: 'Smlouva nenalezena.' });
      if (!maPristupKFirme(uzivatel, smlouva.Firma)) return json(403, { error: 'Nemáte přístup k této firmě.' });

      await deleteRow(sheets, spreadsheetId, 'Smlouvy', smlouva._row);

      // Cascade: bankovní pohyby napojené na smazanou smlouvu appka vrátí
      // do stavu "Nespárováno", ať v Bankovních výpisech nezůstane pohyb
      // odkazující na smlouvu, která už neexistuje (stejný vzor jako
      // cascade při smazání Dokladu, viz netlify/functions/doklady.js).
      try {
        const { rows: pohyby } = await readSheetObjects(sheets, spreadsheetId, 'Bankovni_pohyby');
        const napojenePohyby = pohyby.filter((p) => p.Smlouva_ID === id);
        for (const pohyb of napojenePohyby) {
          const aktualizovany = Object.assign({}, pohyb, { Smlouva_ID: '', Stav_parovani: 'Nespárováno' });
          await updateRow(sheets, spreadsheetId, 'Bankovni_pohyby', BANKOVNI_HEADERS, pohyb._row, aktualizovany);
        }
      } catch (e) {
        // List Bankovni_pohyby nemusí existovat - smazání smlouvy se kvůli
        // tomu nemá zastavit.
      }

      // Cascade (od v3.21): appka smaže i všechny přílohy smlouvy ze
      // Smlouvy_Prilohy (soubory samotné appka na Drive neodstraňuje,
      // stejná konvence jako u smazání Dokladu). Maže od NEJVYŠŠÍHO čísla
      // řádku k nejnižšímu, ať mazání jednoho řádku neposune čísla řádků
      // těch, které appka teprve má smazat.
      try {
        const { rows: prilohyVsechny } = await readSheetObjects(sheets, spreadsheetId, 'Smlouvy_Prilohy');
        const prilohyKSmazani = prilohyVsechny
          .filter((p) => p.Smlouva_ID === id)
          .sort((a, b) => b._row - a._row);
        for (const priloha of prilohyKSmazani) {
          await deleteRow(sheets, spreadsheetId, 'Smlouvy_Prilohy', priloha._row);
        }
      } catch (e) {
        // List Smlouvy_Prilohy nemusí existovat (starší appka bez znovu
        // spuštěného /api/setup) - smazání smlouvy se kvůli tomu nemá zastavit.
      }

      return json(200, { ok: true });
    }

    return json(405, { error: 'Method not allowed' });
  } catch (e) {
    return json(500, { error: e.message });
  }
};
